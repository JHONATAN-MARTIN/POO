package exemplos;

public class Aula {
	public static void main(String[] args) {
		System.out.println("Aula 9");
	//	System.out.println("Nome do usuario:" + args[0]);
	//	System.out.println(args[1]);
		
		//tipos primitivos - armazena valor
		byte num;
		final int numero=0;
		double valor;
		float preco;
		char resposta= 'S';
		boolean achou= false;
		
		//classe armazena uma referencia
		String nome ="Marcelo";	
		System.out.println(nome.toUpperCase());
		System.out.println(nome.length());
	}
}
