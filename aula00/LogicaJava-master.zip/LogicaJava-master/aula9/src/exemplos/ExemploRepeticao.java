package exemplos;

import java.util.Iterator;

public class ExemploRepeticao {

	public static void main(String[] args) {
		
//		int num = 1;
//		while (num <= 10) {
//			System.out.println(num);
//			num++;
//		}
	
//	do {
//		System.out.println(num);
//		num++;
//	} while (num <= 10);
//	
	
		for (int i = 0; i <= 10; i++) {
			if (i == 5 || i == 6) {
				continue;
			}
			System.out.println(i);
		}
		
		
		
		
		
	}
	

}
