package exemplos;

public class Aluno {
		int matricula;
		String nome;
		String telefone;
		String endereco;

}
